package BKRV.review;

public class rvBean {
	
	private int rv_number;
	private int rv_bknumber;
	private String rv_id;
	private String rv_date;
	private int rv_score;
	private String rv_content;
	
	public int getRv_number() {
		return rv_number;
	}
	public void setRv_number(int rv_number) {
		this.rv_number = rv_number;
	}
	public int getRv_bknumber() {
		return rv_bknumber;
	}
	public void setRv_bknumber(int rv_bknumber) {
		this.rv_bknumber = rv_bknumber;
	}
	public String getRv_id() {
		return rv_id;
	}
	public void setRv_id(String rv_id) {
		this.rv_id = rv_id;
	}
	public String getRv_date() {
		return rv_date;
	}
	public void setRv_date(String rv_date) {
		this.rv_date = rv_date;
	}
	public int getRv_score() {
		return rv_score;
	}
	public void setRv_score(int rv_score) {
		this.rv_score = rv_score;
	}
	public String getRv_content() {
		return rv_content;
	}
	public void setRv_content(String rv_content) {
		this.rv_content = rv_content;
	}
	

	
}
